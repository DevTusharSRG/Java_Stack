package com.colab.ColabFarm1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ColabFarm1Application {

	public static void main(String[] args) {
		SpringApplication.run(ColabFarm1Application.class, args);
	}

}
