package com.colab.ColabFarm1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColabFarm1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
