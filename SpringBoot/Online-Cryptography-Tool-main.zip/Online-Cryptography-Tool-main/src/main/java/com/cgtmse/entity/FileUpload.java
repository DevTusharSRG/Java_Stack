package com.cgtmse.entity;

public class FileUpload {

}
