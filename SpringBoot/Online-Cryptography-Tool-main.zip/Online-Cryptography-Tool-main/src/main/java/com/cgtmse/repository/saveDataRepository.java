package com.cgtmse.repository;

import org.springframework.data.repository.CrudRepository;

import com.cgtmse.entity.YourActivity;

public interface saveDataRepository extends CrudRepository<YourActivity, String>{

}
